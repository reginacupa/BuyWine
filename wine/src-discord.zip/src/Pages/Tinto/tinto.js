import React from "react";
import "../Tinto/tinto.css";
import Header from "../../Componentes/Header/header";
import Item from "../../Componentes/Item/item";
//import { UserContext } from "../../Componentes/Context/userContext";
import Product from "../Product";
//import ProductDetails from "../ProductDetails";
import QuantityBuy from "../../Componentes/QuantityBuy";
//import Produtos from "../../Produtos.json";
//import Cards from "../../Componentes/Cards/cards";
import Footer from "../../Componentes/Footer/footer";
import { useNavigate } from "react-router-dom";
import Container from '@mui/material/Container';




function Tinto(){
    const navigate = useNavigate ()

    return(
        <> 
        <section className= "Container">
            <div id= "GridComplexExample"></div>
                <div className="description">
                    <h3>Sempre os melhores produtos para você!!</h3>
                </div>

            <div className="product-content">
                <div className= "product"></div>
                <p>Os melhores vinhos para vc</p>
                <button className= "Mais informações" onClick={() => navigate ('/Item')}>Veja nossos produtos </button>


                   
                
            </div>    
          
        </section>                

        <Header/>
        <Item/>
        <Product/>
        <QuantityBuy/>
        <Footer/>
        </>
    )

}

export default Tinto;

